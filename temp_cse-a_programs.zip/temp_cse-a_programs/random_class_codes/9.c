#include <stdio.h>
#include <stdlib.h>


// int** arr = {
//     int* array1 => a dynamic 1D array;
//     int* array2 => a dynamic 1D array;
//     int* array3 => a dynamic 1D array;
// }

// ** arr = malloc(rows * sizeof(int*));
// arr = ** {
//     *{1, 2, 3},
//     *{4, 5, 6},
//     *{7, 8, 9}
// }

int** create_2d_array(int rows, int cols) {

    malloc(rows * columns * sizeof(int));

    int** array = (int**) malloc(rows * sizeof(int*));
    for (int i = 0; i < rows; i++) {
        array[i] = (int*) malloc(cols * sizeof(int));
        for (int j = 0; j < cols; j++) {
            array[i][j] = i * cols + j + 1;
        }
    }

    return array;
}

int print_sum_rows_and_columns(int** matrix, int rows, int cols) {
    // ROWS
    for (int i = 0; i < rows; i++) {
        int row_sum = 0;
        // COLUMNS
        for (int j = 0; j < cols; j++) {
            row_sum += matrix[i][j];
        }
        printf("Sum of row %d: %d\n", i, row_sum);
    }

    for (int j = 0; j < cols; j++) {
        int col_sum = 0;
        for (int i = 0; i < rows; i++) {
            col_sum += matrix[i][j];
        }
        printf("Sum of column %d: %d\n", j, col_sum);
    }

    return 0;
}

int free_2d_array(int** array, int rows) {

    for (int i = 0; i < rows; i++) {
        free(array[i]);
    }
    free(array);

    return 0;
}

int print_matrix(int **matrix, int rows, int cols) {

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}

int main() {
    int rows = 3, cols = 3;
    int** matrix = create_2d_array(rows, cols);

    print_sum_rows_and_columns(matrix, rows, cols);
    print_matrix(matrix, rows, cols);
    free_2d_array(matrix, rows);
    // print_matrix(matrix, rows, cols);

    return 0;
}


// Address(A[i]) = Base_Address + (i × Size of an Element)

// Address Calculation in a 2D array
// Address(A[i][j]) = Base_Address + [(i × Number of Columns + j) × Size of an Element]

// Address Calculation in a 3D array
// Address(A[i][j][k]) = Base_Address + [(i × Number of Rows per Plane × Number of Columns) + (j × Number of Columns) + k] × Size of an Element

// Class Assignment
// Generalized Formula for an n-dimensional array is ?

// Class Assignment 1. Finding the Trace of a Square Matrix
// Class Assignment 2. Check if a matrix is symmetric

