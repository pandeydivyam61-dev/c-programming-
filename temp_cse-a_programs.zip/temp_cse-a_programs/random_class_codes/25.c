#include <stdio.h>


// Recursion -> a function calling itself
// Fibonacci Number
// 0 1 1 2 3 5 8 13 21 .....
// get_fib(0) = 0
// get_fib(1) = 1
// get_fib(2) = 1
// get_fib(3) = 2
// .
// .
// .
// get_fib(n - 2)
// get_fib(n - 1)
// get_fib(n)
// Division of Problems to subproblems

// Divide and Conquer


int get_fib_recursive(int n) {

    if (n == 0) {
        return 0;
    }
    else if (n == 1) {
        return 1;
    }

    // return function_call_1() + function_call_2()
    // Activation Stack -> multiple data items for each function
    // in the activation record
    // Main Memory has a certain HARD LIMIT for Activation Stack Size
    return get_fib_recursive(n - 1) + get_fib_recursive(n - 2);
}

// int get_fib(int b) {
//     get_fib(b);
// }
// infinitely being stored in the Activation Stack

// Write a C function print n Fibonacci Numbers using Recursive
// and Iterative Solutions

int get_fib_iterative(int n) {

    if (n == 0) {
        return 0;
    }
    if (n == 1) {
        return 1;
    }

    // Iterative component of the solution
    int a = 0, b = 1, fib = 0;
    for (int i = 2; i <= n; i++) {
        fib = a + b;
        a = b;
        b = fib;
    }
    // Consuming Less Memory Space, Iterative Solutions are 
    // better than Recursive Solutions (Lesser Space Complexity)

    return fib;
}

int main() {
    int n = 10;

    printf("Recursive Fibonacci of %d: %d\n", n, get_fib_recursive(n));
    printf("Iterative Fibonacci of %d: %d\n", n, get_fib_iterative(n));

    return 0;
}
