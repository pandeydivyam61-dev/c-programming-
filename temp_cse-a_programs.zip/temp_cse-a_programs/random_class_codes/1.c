// Access & Modify Array Elements
#include <stdio.h>


int main() {
    int numbers[5] = {10, 20, 30, 40, 50};
    // Linear data structure

    // Accessing and printing array elements
    printf("The first element is %d\n", numbers[0]);
    printf("The second element is %d\n", numbers[1]);

    // Modifying an array element
    numbers[2] = 100;
    printf("The modified third element is %d\n", numbers[2]);

    return 0;
}
