#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to demonstrate static and dynamic int arrays
int handle_int_array() {
    printf("\n--- Handling Integer Array ---\n");

    // Static int array
    int static_int_array[5] = {1, 2, 3, 4, 5};
    printf("Static int array values:\n");
    for (int i = 0; i < 5; i++) {
        printf("%d ", static_int_array[i]);
    }
    printf("\n");

    // Dynamic int array
    int* dynamic_int_array = (int*) malloc(5 * sizeof(int));
    if (dynamic_int_array == NULL) {
        printf("Memory allocation failed!\n");
        return -1;
    }
    for (int i = 0; i < 5; i++) {
        dynamic_int_array[i] = i + 6;  // Initialize values starting from 6
    }

    printf("Dynamic int array values:\n");
    for (int i = 0; i < 5; i++) {
        printf("%d ", dynamic_int_array[i]);
    }
    printf("\n");
    
    // Free the dynamic array
    free(dynamic_int_array);

    return 0;
}

// Function to demonstrate static and dynamic float arrays
int handle_float_array() {
    printf("\n--- Handling Float Array ---\n");

    // Static float array
    float static_float_array[5] = {1.1, 2.2, 3.3, 4.4, 5.5};
    printf("Static float array values:\n");
    for (int i = 0; i < 5; i++) {
        printf("%.1f ", static_float_array[i]);
    }
    printf("\n");

    // Dynamic float array
    float* dynamic_float_array = (float*) malloc(5 * sizeof(float));
    if (dynamic_float_array == NULL) {
        printf("Memory allocation failed!\n");
        return -1;
    }
    for (int i = 0; i < 5; i++) {
        dynamic_float_array[i] = (i + 6) * 1.1f;  // Initialize values starting from 6.6
    }

    printf("Dynamic float array values:\n");
    for (int i = 0; i < 5; i++) {
        printf("%.1f ", dynamic_float_array[i]);
    }
    printf("\n");

    // Free the dynamic array
    free(dynamic_float_array);

    return 0;
}

// Function to demonstrate static and dynamic char arrays
int handle_char_array() {
    printf("\n--- Handling Char Array ---\n");

    // Static char array
    char static_char_array[6] = "mister";  // Strings in C end with '\0'
    printf("Static char array values:\n");
    for (int i = 0; i < 6; i++) {
        printf("%c ", static_char_array[i]);
    }
    printf("\n");

    // Dynamic char array
    char* dynamic_char_array = (char*) malloc(6 * sizeof(char));  // Allocating space for "world"
    if (dynamic_char_array == NULL) {
        printf("Memory allocation failed!\n");
        return -1;
    }
    // Solution - strcpy(dynamic_char_array, "hello");
    


    // dynamic_char_array = "hello\0";
    // Assignment question - If the above line is used instead of lines 106-111(individual character assignment), why does the compiler throw an error?


    // Explanation
    // This line doesn’t copy the contents of "hello" into the dynamically allocated memory. Instead, it makes dynamic_char_array point to a string literal "hello" stored in the read-only section of memory. By assigning "hello" directly, you lose the reference to the memory allocated by malloc, which causes two main problems:

    // Memory Leak: The allocated memory is no longer accessible, as dynamic_char_array now points to "hello".
    // Invalid Free: Attempting to free(dynamic_char_array) at the end of the code results in undefined behavior, as you’re trying to free a string literal, which is not allowed.
    // In contrast, the second code block manually assigns each character to the allocated memory, which correctly fills the array in a writable memory area. This way, dynamic_char_array still points to the memory allocated by malloc, making free(dynamic_char_array) safe.

    // To fix the first code, you should copy the string "hello" into the allocated memory using strcpy

    dynamic_char_array[0] = 'w';
    dynamic_char_array[1] = 'o';
    dynamic_char_array[2] = 'r';
    dynamic_char_array[3] = 'l';
    dynamic_char_array[4] = 'd';
    dynamic_char_array[5] = '\0';  // Null-terminate the string

    printf("Dynamic char array values (as a string): %s\n", dynamic_char_array);

    // Free the dynamic array
    free(dynamic_char_array);

    return 0;
}

// Function to demonstrate static and dynamic double arrays
int handle_double_array() {
    printf("\n--- Handling Double Array ---\n");

    // Static double array
    double static_double_array[5] = {1.11, 2.22, 3.33, 4.44, 5.55};
    printf("Static double array values:\n");
    for (int i = 0; i < 5; i++) {
        printf("%.2lf ", static_double_array[i]);
    }
    printf("\n");

    // Dynamic double array
    double *dynamic_double_array = (double*)malloc(5 * sizeof(double));
    if (dynamic_double_array == NULL) {
        printf("Memory allocation failed!\n");
        return -1;
    }
    for (int i = 0; i < 5; i++) {
        dynamic_double_array[i] = (i + 6) * 1.11;  // Initialize values starting from 6.66
    }

    printf("Dynamic double array values:\n");
    for (int i = 0; i < 5; i++) {
        printf("%.2lf ", dynamic_double_array[i]);
    }
    printf("\n");

    // Free the dynamic array
    free(dynamic_double_array);

    return 0;
}

int main() {
    handle_int_array();
    handle_float_array();
    handle_char_array();
    handle_double_array();
    return 0;
}
