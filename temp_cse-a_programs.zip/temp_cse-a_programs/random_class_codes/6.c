#include <stdio.h>
#include <stdlib.h>


int main() {
    int n;

    scanf("%d", &n);
    // Dynamic Memory Allocation
    // Dynamic Memory Heap / Dynamic Heap Memory
    int* array = (int*) malloc(sizeof(int) * n);
    // data_type* array = (data_type*) malloc(sizeof(data_type) * num_elements);

    // Initializing array elements
    for (int i = 0; i < n; i++) {
        array[i] = i + 1;
    }

    // Printing array elements
    for (int i = 0; i < n; i++) {
        printf("Element %d is %d\n", i, array[i]);
    }

    // Freeing allocated memory
    free(array);

    return 0;
}
 