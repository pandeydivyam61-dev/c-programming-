#include <stdio.h>


int main() {

    int matrix[2][3] = {
        {1, 2, 3},
        {4, 5, 6}
    };
    // Can int* can be used to manipulate int[]?


    // Can int** be used to manipulate int[][]?

    // Can int* be used to point to a int[] array?
    // Can int** be used to point to a int[][] array? - No

    // int** => No knowledge of the data being stored in Col_major or Row_major order - No standard address calculation formula as per any storage order

    // int[][] => A certain order associated (Row_major) => Address Calculation Formula

    // C static arrays of any data type are stored contiguously in the memory
    // Linear Order -> Row-Major Order
    // int *ptr

    int (*ptr_1)[3] = matrix;

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%d ", ptr_1[i][j]); // arr[i][j] is basically 2-D indexing
        }
        printf("\n");
    }

    return 0;
}
