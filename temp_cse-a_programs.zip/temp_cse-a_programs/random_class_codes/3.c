#include <stdio.h>


int main() {
    int matrix[2][3] = {
        {1, 2, 3},
        {4, 5, 6}
    };

    // int arr_2d[m][n] => 
    // m is the number of rows and n is the number of columns


    // Accessing and printing 2D array elements
    printf("Element at [0][1]: %d\n", matrix[0][1]);
    printf("Element at [1][2]: %d\n\n", matrix[1][2]);

    // Looping through a 2D array
    for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
            printf("Element at [%d][%d]: %d\n", i, j, matrix[i][j]);
        }
    }

    return 0;
}
