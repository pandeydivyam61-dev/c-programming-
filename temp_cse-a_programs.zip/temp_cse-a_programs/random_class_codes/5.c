// Print the decimal equivalent of a hexadecimal memory address
#include <stdio.h>
#include <stdlib.h>


int main() {
    const char* hex_address_1 = "0x16cf5f200";
    const char* hex_address_2 = "0x16cf5f204";

    long decimal_address = strtol(hex_address_1, NULL, 16);
    printf("Decimal equivalent: %ld\n", decimal_address);

    decimal_address = strtol(hex_address_2, NULL, 16);
    printf("Decimal equivalent: %ld\n", decimal_address);

    return 0;
}
