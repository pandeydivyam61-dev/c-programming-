#include <stdio.h>
#include <stdlib.h>


int** allocate_2d_array(int rows, int cols) {
    int** matrix = (int**) malloc(rows * sizeof(int*));
    for (int i = 0; i < rows; i++) {
        matrix[i] = (int*) malloc(cols * sizeof(int));
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = i + 2 * j;
        }
    }

    return matrix;
}

int deallocate_2d_array(int **matrix, int rows) {
    for (int i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);

    return 0;
}

int** transpose_matrix(int** matrix, int rows, int cols, <param 4>) {
    // On the basis of this param, you will choose one of the following options
    // 1. Do not create a new 2D space to store the transposed matrix 
    // 2.  Create space using malloc, sotre the transposed matrix in this new space
    int** transpose = (int**) malloc(cols * sizeof(int*));
    for (int i = 0; i < cols; i++) {
        transpose[i] = (int*)malloc(rows * sizeof(int));
        for (int j = 0; j < rows; j++) {
            transpose[i][j] = matrix[j][i];
        }
    }

    return transpose;
}

int print_matrix(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}

int main() {

    int rows = 3, cols = 3;
    int** matrix = allocate_2d_array(rows, cols);
    int** transpose = transpose_matrix(matrix, rows, cols);

    printf("Original Matrix:\n");
    print_matrix(matrix, cols, rows);

    printf("Transposed Matrix:\n");
    print_matrix(transpose, cols, rows);

    deallocate_2d_array(matrix, rows);
    deallocate_2d_array(transpose, cols);

    return 0;
}
