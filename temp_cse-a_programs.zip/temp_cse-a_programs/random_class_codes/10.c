#include <stdio.h>
#include <stdlib.h>


int** create_matrix(int rows, int cols) {

    int** matrix = (int**) malloc(rows * sizeof(int*));

    for (int i = 0; i < rows; i++) {
        matrix[i] = (int*) malloc(cols * sizeof(int));
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = i + j + 1;
        }
    }

    return matrix;
}

int** multiply_matrices(int** matA, int** matB, int rowsA, int colsA, int colsB) {

    int** result = (int**) malloc(rowsA * sizeof(int*));

    for (int i = 0; i < rowsA; i++) {

        result[i] = (int*) calloc(colsB, sizeof(int));
        for (int j = 0; j < colsB; j++) {
            for (int k = 0; k < colsA; k++) {
                result[i][j] += matA[i][k] * matB[k][j];
                printf("%d ,", result[i][j]);
            } 
            printf("\n");
        }
        printf("\nDealt with row %d!\n", i);
    }

    return result;
}

int free_matrix(int** matrix, int rows) {
    for (int i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);

    return 0;
}

int print_matrix(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}

int main() {

    int** matA = create_matrix(2, 3);
    int** matB = create_matrix(3, 2);
    int** result = multiply_matrices(matA, matB, 2, 3, 2);

    print_matrix(matA, 2, 3);
    print_matrix(matB, 3, 2);

    printf("Resulting Matrix:\n");
    print_matrix(result, 2, 2);

    free_matrix(matA, 2);
    free_matrix(matB, 3);
    free_matrix(result, 2);

    return 0;
}
