#include <stdio.h>

// 2 ^ 5
// 2 * 2 * 2 * 2 * 2 (exp number of times)
// 2 ^ -5
// (1/2) * (1/2) ..... (5 times)

double power(double base, int exp) {
    if (exp == 0) {
        return 1;
        // Base case
    }
    else if (exp > 0) {
        return base * power(base, exp - 1);
    }
    else {
        return 1 / power(base, -exp);
    }
}

// power(2.0, 3) = 8.0
// 2.0 * (2.0 * (2.0 * 1)) = 8.0

// Write an equivalent program in C to calculate
// the factorial of n.

// get_factorial(5)
// 5 * (4 * (3 * get_factorial(2)))...


int main() {
    double base = 2.0;
    int exp = 3;
    printf("Power: %.4f", power(base, exp));

    return 0;
}
