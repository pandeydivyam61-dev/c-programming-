#include <stdio.h>


int main() {
    int numbers[5] = {10, 20, 30, 40, 50};

    // Looping through array and printing elements
    for (int i = 0; i < 5; i++) {
        printf("Element at index %d is %d\n", i, numbers[i]);
        printf("Address of element at index %d: %p\n", i, &numbers[i]);
    }

    return 0;
}
