#include <stdio.h>


int print_arr(int* arr, int n) {

    printf("\t");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}

int main() {

    int a[6] = {10, 2, 3, 4, 5, 6};

    int* p;

    
    
    // p = &a; // LHS (int *) = RHS (int (*)[6]) // incompatible pointer types
    // Correct behavior of this assignment depends on the underlying memory addressing mechanism 
    // dicatated by the HW / OS

    // To ensure Type Safety for better memory addressing
    // p = (void*) &a; // Type of LHS (int *) = Type of RHS (void *))
    p = a;

    print_arr(a, 6);
    print_arr(p, 6);


    // Pointer Arithmetic
    printf("\na. Value at p = %d\n", *p);

    p++;

    printf("\nb. Value at p after increment = %d\n", *p);
    printf("\nc. %p\n", (void*)p);
    // p--;

    // printf("\nd. Value at p after decrement = %d\n", *p);

    // Prints the memory address stored in p, which is the address of the first element
    // of the array a.
    printf("\ne. %p\n", (void*)p);

    // Dereferences p and prints the value at the address it points to,
    // which is 1 (the first element of the array).
    printf("\nf. %d\n", *p);

    // Prints the address of the array a, which is the same as the address of
    // its first element.
    printf("\ng. %p\n", a);

    // Prints the first element of the array, which is 1.
    printf("\nh. %d\n", a[0]);

    // Prints the memory address of the pointer p itself.
    printf("\ni. %p\n", &p);

    // Increments the value at which p points by 1,
    // making the first element of a now 2, and then prints it.
    printf("\nj. %d\n", ++(*p));
    print_arr(a, 6);
    print_arr(p, 6);

    // Moves the pointer p to the next integer in the array (i.e., to a[1]),
    // and then prints the value there, which is 2.
    printf("\nk. %d\n", *(++p));
    print_arr(a, 6);
    print_arr(p, 6);

    // Prints the value at the current location of p (which is 2),
    // and then increments p to point to the next element (a[2]).
    printf("\nl. %d\n", *p++); // Post-increment operator
    print_arr(a, 6);
    print_arr(p, 6);

    // Prints the value at the current location of p, which is now 3.
    printf("\nm. %d\n", *p);
    print_arr(a, 6);
    print_arr(p, 6);

    // Prints the value at the current location of p, which is 3,
    // and then increments p to point to the next element.
    printf("\nn. %d\n", *(p++)); // post-increment
    print_arr(a, 6);
    print_arr(p, 6);

    return 0;
}
