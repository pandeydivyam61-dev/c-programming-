#include <stdio.h>

// typedef is used to define UDTs (User-defined Data Types)

double add(double a, double b) {
    return a + b;
}

double subtract(double a, double b) {
    return a - b;
}

double multiply(double a, double b) {
    return a * b;
}

double divide(double a, double b) {
    if (b != 0) {
        return a / b;
    }
    else {
        return 0;
    }
}

// Function Pointer
typedef double (*operation_func)(double, double);

double calculate(double a, double b, operation_func op) {
    return op(a, b);
}


// Hierarchy of operations / functions
// subcategory function (is a) supercategory function
// addition (is a) calculation
// subtraction (is a) calculation
// multiplication (is a) calculation
// division (is a) calculation


int main() {

    double num1, num2;
    char op;

    printf("Enter an operation (+, -, *, /): ");
    scanf(" %c", &op);
    printf("Enter two numbers: ");
    scanf("%lf %lf", &num1, &num2);

    operation_func func = NULL;
    // data_type variable_name = value;

    // double (*func)(double, double);
    // func = NULL;

    switch (op) {
        case '+':
            func = add;
            break;
        case '-':
            func = subtract;
            break;
        case '*':
            func = multiply;
            break;
        case '/':
            func = divide;
            break;
        default:
            printf("Invalid operation!\n");
            return 1;
    }

    double result = calculate(num1, num2, func);
    printf("Result: %lf\n", result);

    return 0;
}
