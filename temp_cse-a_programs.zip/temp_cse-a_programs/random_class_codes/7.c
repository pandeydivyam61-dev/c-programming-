#include <stdio.h>
#include <stdlib.h>  // For malloc, realloc, free


int demonstrate_static_array() {
    printf("Static Array:\n");

    // 1. Static array allocation (compile-time memory allocation, on stack)
    int static_array[5];  // Static array of fixed size 5

    // 2. The size is fixed, cannot be changed
    printf("Size of static array: %lu bytes\n", sizeof(static_array));

    // 3. By default, the elements are initialized to zero (for global/static variables) or garbage (for local variables)
    printf("Initial values in static array:\n");
    for (int i = 0; i < sizeof(static_array) / sizeof(int); i++) {
        printf("static_array[%d] = %d\n", i, static_array[i]);  // May show uninitialized garbage values for local array
    }

    // 4. Static arrays cannot be erased, their memory is automatically deallocated when the function scope ends

    return 0;
}

int demonstrate_dynamic_array() {
    printf("\nDynamic Array:\n");

    // 1. Dynamic array allocation (runtime memory allocation, on heap)
    int size = 5;
    int* dynamic_array = (int*) malloc(size * sizeof(int));  // Dynamic array of size 5

    if (dynamic_array == NULL) {
        printf("Memory allocation failed!\n");
        return -1;
    }

    // 2. Initially, dynamic memory may contain garbage values if not explicitly initialized
    printf("Initial values in dynamic array (may be garbage values):\n");
    for (int i = 0; i < size; i++) {
        printf("dynamic_array[%d] = %d\n", i, dynamic_array[i]);  // Garbage values
    }

// A for loop to initialize the 5 dynamic_array values.
// Then, realloc, read through the 10 values.

    // 3. We can change the size of the dynamic array using realloc (size is not fixed)
    dynamic_array = (int*) realloc(dynamic_array, 10 * sizeof(int));  // Increase size to 10

    if (dynamic_array == NULL) {
        printf("Memory reallocation failed!\n");
        return -1;
    }

    printf("\nDynamic array size increased to 10\n");
    for (int i = 0; i < 10; i++) {
        dynamic_array[i] = i + 1;  // Initialize array with some values
        printf("dynamic_array[%d] = %d\n", i, dynamic_array[i]);
    }

    // 4. Dynamic arrays can be erased manually using free
    free(dynamic_array);  // Free the allocated memory
    dynamic_array = NULL; // After freeing, the pointer should not be accessed

    // 5. Trying to access the dynamic array after freeing it results in undefined behavior
    if (dynamic_array != NULL) {
        printf("dynamic_array[0] after free: %d\n", dynamic_array[0]);  // Undefined behavior
    } 
    else {
        printf("\nDynamic array has been freed and cannot be accessed.\n");
    }

    return 0;
}

int main() {
    demonstrate_static_array();
    demonstrate_dynamic_array();
    return 0;
}
